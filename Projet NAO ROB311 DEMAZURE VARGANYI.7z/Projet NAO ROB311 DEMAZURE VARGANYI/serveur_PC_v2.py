# -*- coding: utf-8 -*-
"""
Created on Tue Nov 19 10:03:09 2024

@author: orsod
"""
import cv2
import mediapipe as mp
import numpy as np
import socket
import time

NAO_IP = "169.254.192.168"

# Initialisation Mediapipe Pose & Hand
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()

mp_hands = mp.solutions.hands
hands = mp_hands.Hands()

mp_drawing = mp.solutions.drawing_utils

print("mediapipe initialized")

# Fonction pour calculer les angles entre trois points
def calculate_angle(a, b, c):
    a = np.array(a)  # Point 1
    b = np.array(b)  # Point 2 (vertex)
    c = np.array(c)  # Point 3

    radians = np.arctan2(c[1]-b[1], c[0]-b[0]) - np.arctan2(a[1]-b[1], a[0]-b[0])
    angle = np.abs(np.degrees(radians))
    if angle > 180.0:
        angle = 360 - angle
    return angle

# Fonction pour détecter la position "O"
def detect_position_O(landmarks, mp_pose, image):
    if (landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].visibility > 0.5):

        shoulder_left = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                         landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        elbow_left = [landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                      landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
        wrist_left = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                      landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]

        shoulder_right = [landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
                          landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y]
        elbow_right = [landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value].x,
                       landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value].y]
        wrist_right = [landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].x,
                       landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].y]

        angle_left_elbow = calculate_angle(shoulder_left, elbow_left, wrist_left)
        angle_right_elbow = calculate_angle(shoulder_right, elbow_right, wrist_right)

        if (100 < angle_left_elbow < 140 and 100 < angle_right_elbow < 140 and
            abs(wrist_left[0] - wrist_right[0]) < 0.1 and
            abs(wrist_left[1] - wrist_right[1]) < 0.1 and
            wrist_left[1] < shoulder_left[1] and wrist_right[1] < shoulder_right[1]):
            cv2.putText(image, "Position: O detected", (50, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
            return True
    return False

# Fonction pour détecter la position "K"
def detect_position_K(landmarks, mp_pose, image):
    if (landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].visibility > 0.5 and
        landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].visibility > 0.5):
        
        # Repères du côté gauche
        shoulder_left = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                         landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        hip_left = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,
                    landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]
        knee_left = [landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                     landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].y]
        wrist_left = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                      landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
        
        # Repères du côté droit
        shoulder_right = [landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
                          landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y]
        hip_right = [landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].x,
                     landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].y]
        knee_right = [landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].x,
                      landmarks[mp_pose.PoseLandmark.RIGHT_KNEE.value].y]
        wrist_right = [landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].x,
                       landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].y]

        # Vérification des angles pour les bras
        arm_left_angle = calculate_angle(hip_left, shoulder_left, wrist_left)  # Angle pour le bras gauche
        arm_right_angle = calculate_angle(hip_right, shoulder_right, wrist_right)  # Angle pour le bras droit
        
        # Vérification des angles pour les jambes
        leg_left_angle = calculate_angle(shoulder_left, hip_left, knee_left)  # Jambe gauche
        leg_right_angle = calculate_angle(shoulder_right, hip_right, knee_right)

        # Détection de la position "K"
        if (arm_left_angle > 168 and 135 < arm_right_angle < 165 and
            leg_left_angle > 167 and 164 < leg_right_angle < 173):
            head_nose = [landmarks[mp_pose.PoseLandmark.NOSE.value].x, landmarks[mp_pose.PoseLandmark.NOSE.value].y]
            if wrist_left[1] < head_nose[1] and wrist_right[1] < head_nose[1]:
                cv2.putText(image, "Position: K detected", (50, 250), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                return True
    return False


def detect_position(landmarks, mp_pose, image, data):
    if data == "position_O" and detect_position_O(landmarks, mp_pose, image):
        return True
    elif data == "position_K" and detect_position_K(landmarks, mp_pose, image):
        return True
    else:
        return False
    

def count_fingers(hand_landmarks, mp_hands):

    finger_align = {
        'thumb': [mp_hands.HandLandmark.THUMB_CMC,mp_hands.HandLandmark.THUMB_MCP,mp_hands.HandLandmark.THUMB_IP,mp_hands.HandLandmark.THUMB_TIP],
        'index': [mp_hands.HandLandmark.INDEX_FINGER_MCP,mp_hands.HandLandmark.INDEX_FINGER_PIP,mp_hands.HandLandmark.INDEX_FINGER_DIP,mp_hands.HandLandmark.INDEX_FINGER_TIP],
        'middle': [mp_hands.HandLandmark.MIDDLE_FINGER_MCP,mp_hands.HandLandmark.MIDDLE_FINGER_PIP,mp_hands.HandLandmark.MIDDLE_FINGER_DIP,mp_hands.HandLandmark.MIDDLE_FINGER_TIP],
        'ring': [mp_hands.HandLandmark.RING_FINGER_MCP,mp_hands.HandLandmark.RING_FINGER_PIP,mp_hands.HandLandmark.RING_FINGER_DIP,mp_hands.HandLandmark.RING_FINGER_TIP],
        'pinky': [mp_hands.HandLandmark.PINKY_MCP,mp_hands.HandLandmark.PINKY_PIP,mp_hands.HandLandmark.PINKY_DIP,mp_hands.HandLandmark.PINKY_TIP]
    }

    # Initialisation du compteur de doigts levés
    finger_count = 0

    wrist_y = hand_landmarks.landmark[mp_hands.HandLandmark.WRIST].y

    # Vérification de chaque doigt
    for finger, landmarks in finger_align.items():
        # Récupération des coordonnées `y` pour le doigt
        y_coords = [hand_landmarks.landmark[lm].y for lm in landmarks]

        # Vérification de l'ordre croissant des `y` (du plus bas au plus haut)
        if y_coords == sorted(y_coords, reverse=True) and y_coords[-1] < wrist_y:
            # Cas particulier pour le pouce
            if finger == 'thumb':
                thumb_tip_x = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP].x
                thumb_ip_x = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_IP].x
                thumb_MCP_x = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_MCP].x
                pinky_MCP_x = hand_landmarks.landmark[mp_hands.HandLandmark.PINKY_MCP].x
                if pinky_MCP_x > thumb_MCP_x: # vérification main gauche
                    if thumb_tip_x <= thumb_ip_x:  # Vérification horizontale
                        finger_count += 1
                elif pinky_MCP_x < thumb_MCP_x: # vérification main droite
                    if thumb_tip_x >= thumb_ip_x:  # Vérification horizontale
                        finger_count += 1
            else:
                finger_count += 1

    return finger_count


def dynamic_threshold_adjustment(angle_hip_shoulder_elbow):
    if angle_hip_shoulder_elbow < 45:
        threshold = angle_hip_shoulder_elbow - 5  # Réduction de 5°
    elif angle_hip_shoulder_elbow <= 70:
        threshold = angle_hip_shoulder_elbow
    else:
        threshold = angle_hip_shoulder_elbow + 5  # Augmentation de 5°
    
    return threshold

def detect_wave(landmarks, mp_pose, image, state, side):
    if side == 'right':
        wrist = [landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].x,
                 landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value].y]
        elbow = [landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value].x,
                 landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value].y]
        shoulder = [landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
                    landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y]
        hip = [landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].x,
               landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value].y]
    else:
        wrist = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                 landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
        elbow = [landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                 landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
        shoulder = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                    landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
        hip = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,
               landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]

    if state[side]['last_change_time'] == 0:
        state[side]['last_change_time'] = time.time()

    angle_wrist_elbow_shoulder = calculate_angle(wrist, elbow, shoulder)
    angle_hip_shoulder_elbow = calculate_angle(hip, shoulder, elbow)

    threshold = dynamic_threshold_adjustment(angle_hip_shoulder_elbow)

    if wrist[1] < elbow[1]:
        current_time = time.time()
        if angle_wrist_elbow_shoulder < threshold:  # Main en bas
            state[side]['current'] = 'down'
        elif angle_wrist_elbow_shoulder > threshold:  # Main en haut
            state[side]['current'] = 'up'
        
        time_diff = current_time - state[side]['last_change_time']

        if state[side]['current'] != state[side]['previous'] and time_diff <= 1:
            state[side]['wave_count'] += 1
            state[side]['last_change_time'] = current_time
            state[side]['previous'] = state[side]['current']
        if time_diff > 2.5:
            # if movement too slow = reset
            state[side]['wave_count'] = 0
            state[side]['last_change_time'] = current_time
            state[side]['previous'] = state[side]['current']
        
        # Validation du mouvement
        if state[side]['wave_count'] >= 4:  # 3 aller-retours -> 6 transitions
            x_offset = 100 if side == 'left' else 700
            cv2.putText(image, f"Hello detected ({side.capitalize()})!", 
                        (x_offset, 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            return True
            
    return False


def arms_along_body(landmarks, mp_pose, threshold=0.05):
    """
    Vérifie si les bras sont le long du corps.
    """
    left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
    right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
    left_elbow = landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value]
    right_elbow = landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value]
    left_wrist = landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value]
    right_wrist = landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value]
    
    # Vérifier si les x des poignets et coudes sont proches de ceux des épaules
    left_arm_ok = (
        abs(left_wrist.x - left_shoulder.x) < threshold and 
        abs(left_elbow.x - left_shoulder.x) < threshold
    )
    right_arm_ok = (
        abs(right_wrist.x - right_shoulder.x) < threshold and 
        abs(right_elbow.x - right_shoulder.x) < threshold
    )
    
    return left_arm_ok and right_arm_ok

def detect_bow(landmarks, mp_pose, image, state):
    """
    Detects and tracks the bow motion state using pose landmarks.
    """
    # Extract landmarks
    left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
    right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
    left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP.value]
    right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value]

    shoulder_height = (left_shoulder.y + right_shoulder.y) / 2
    hip_height = (left_hip.y + right_hip.y) / 2
    shoulder_to_hip_distance = abs(shoulder_height - hip_height)

    # Arms along the body condition
    if arms_along_body(landmarks, mp_pose):
        if state['bow_state'] == 'none':
            state['bow_state'] = 'init_timer'
            state['init_timer_start'] = time.time()  # Start initialization timer

        elif state['bow_state'] == 'init_timer':
            if (time.time() - state['init_timer_start']) >= 1.5:
                state['bow_state'] = 'init'
                state['initial_hip_height'] = hip_height
                state['initial_shoulder_height'] = shoulder_height
                state['initial_shoulder_hip_distance'] = shoulder_to_hip_distance

        elif state['bow_state'] == 'init':
            threshold_distance = state['initial_shoulder_hip_distance'] * 0.7
            if shoulder_to_hip_distance <= threshold_distance:
                if state['descend_timer'] is None:
                    state['descend_timer'] = time.time()
                else:
                    if (time.time() - state['descend_timer']) >= 1.0:
                        state['bow_state'] = 'descending_complete'
            else:
                state['descend_timer'] = None

        elif state['bow_state'] == 'descending_complete':
            shoulder_tolerance = 0.02
            hip_tolerance = 0.02
            if (abs(shoulder_height - state['initial_shoulder_height']) < shoulder_tolerance and
                abs(hip_height - state['initial_hip_height']) < hip_tolerance):
                return 1
    else:
        # Reset state if arms are not along the body
        state['bow_state'] = 'none'
        state['init_timer_start'] = None
        state['descend_timer'] = None
        if state['bow_state']== 'init' or state['bow_state'] == 'descending_complete':
            return 2

    # Display current state
    cv2.putText(image, f"State: {state['bow_state']}", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)
    return 0

def main(NAO_IP):
    host = NAO_IP  # Adresse IP de NAO
    port = 5000              # Assurez-vous que le port correspond à celui de NAO

    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("Connexion au serveur...")
        client.connect((host, port))
        print("Connexion réussie")
    except Exception as e:
        print("Erreur côté client : {}".format(e))

    # Variables d'état
    position_detected_start = None
    timeout = 30
    detect_duration = 1
    hold_duration = 4
    detecting = False

    try:
        while True:
            data = client.recv(1024).decode('utf-8')
            if not data:
                break
            print(f"Reçu : {data}")

            if data.strip() == "position_O":
                detecting = True
                timer_start = None
                position_detected_start = None
                hold_start = None
                client.send(b"Detection started\n")
                data_string = "position_O"
            
            if data.strip() == "position_K":
                detecting = True
                timer_start = None
                position_detected_start = None
                hold_start = None
                client.send(b"Detection started\n")
                data_string = "position_K"

            if data.strip() == "count_fingers":
                detecting = True
                timer_start = None
                finger_detected_start = None
                validated_finger_count = None
                data_string = "count_fingers"
            
            if data.strip() == "waving":
                detecting = True
                timer_start = None
                state_waving = {
                    'right': {'current': None, 'previous': None, 'wave_count': 0, 'last_change_time': 0},
                    'left': {'current': None, 'previous': None, 'wave_count': 0, 'last_change_time': 0}
                    }
                data_string = "waving"
                
            if data.strip() == "bowing":
                detecting = True
                timer_start = None
                state_bowing = {
                    'bow_state': 'none',
                    'initial_hip_height': None,  
                    'initial_shoulder_height': None,  
                    'initial_shoulder_hip_distance': None,
                    'init_timer_start' : None,
                    'descend_timer' : None
                }
                data_string = "bowing"

            while detecting :
                ret, frame = cap.read()
                if not ret:
                    break
                
                image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                pose_results = pose.process(image)
                hand_results = hands.process(image)

                # Dessiner les landmarks si détectés
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                if data_string == "count_fingers":
                    finger_count = 0
                    if not timer_start :
                        timer_start = time.time()

                    if hand_results.multi_hand_landmarks:
                        for hand_landmarks in hand_results.multi_hand_landmarks:
                            # Dessiner uniquement les landmarks des mains
                            mp_drawing.draw_landmarks(image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                            # Compter les doigts levés pour chaque main
                            finger_count = count_fingers(hand_landmarks, mp_hands)

                        # Afficher le nombre de doigts levés sur l'image
                        cv2.putText(image, f"Fingers raised: {finger_count}", (50, 150),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

                        # Vérifier si le nombre de doigts reste stable pendant 5 secondes
                        if validated_finger_count is None or validated_finger_count != finger_count:
                            validated_finger_count = finger_count
                            finger_detected_start = time.time()
                        elif time.time() - finger_detected_start >= 5:
                            if validated_finger_count == 1:
                                client.send(b"one_finger\n")
                                detecting = False  # Sortir de la boucle de détection
                                break
                            elif validated_finger_count == 2:
                                client.send(b"two_fingers\n")
                                detecting = False  # Sortir de la boucle de détection
                                break
                            else:
                                client.send(b"wrong_nb_fingers\n")

                else:
                    if pose_results.pose_landmarks:
                        mp_drawing.draw_landmarks(image, pose_results.pose_landmarks, mp_pose.POSE_CONNECTIONS)
                        landmarks = pose_results.pose_landmarks.landmark
                        if data_string in ["position_O", "position_K"]:
                            if not timer_start :
                                timer_start = time.time()
                            if detect_position(landmarks, mp_pose, image, data_string):
                                if not position_detected_start:
                                    position_detected_start = time.time()
                                elif time.time() - position_detected_start >= detect_duration:
                                    if not hold_start:
                                        hold_start = time.time()
                                        client.send(b"position_detected\n")
                                    elif time.time() - hold_start >= hold_duration:
                                        client.send(b"position_held\n")
                                        detecting = False
                            else:
                                position_detected_start = None
                                hold_start = None
                        elif data_string == "waving":
                            right_waving = detect_wave(landmarks, mp_pose, image, state_waving, side='right')
                            left_waving = detect_wave(landmarks, mp_pose, image, state_waving, side='left')
                            if right_waving or left_waving:
                                client.send(b"wave_validated\n")
                                detecting = False
                        elif data_string == "bowing":
                            if not timer_start :
                                timer_start = time.time()
                            bowing_detected = detect_bow(landmarks, mp_pose, image, state_bowing)
                            if bowing_detected == 1:
                                client.send(b"bowing_validated\n")
                                detecting = False
                            elif bowing_detected == 2:
                                client.send(b"arms_near_body\n")
                        

                if timer_start != None and time.time() - timer_start > timeout :
                    client.send(b"TIMEOUT\n")
                    detecting = False

                cv2.imshow('Detection', image)

                if cv2.waitKey(10) & 0xFF == ord('q'):
                    detecting = False
                    break

    except Exception as e:
        print(f"Erreur serveur : {e}")
    finally:
        client.close()
        cap.release()
        cv2.destroyAllWindows()
        print("Connexion fermée")

# Lancement du serveur TCP
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

print("cap initialized")

main(NAO_IP)
