<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/arm near body</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Keep your arm closer to your body</source>
            <comment>Text</comment>
            <translation type="unfinished">Keep your arm closer to your body</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/detected</name>
        <message>
            <source>Great ! Hold it now</source>
            <comment>Text</comment>
            <translation type="obsolete">Great ! Hold it now</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/intro dynamic</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>begin dynamic</source>
            <comment>Text</comment>
            <translation type="unfinished">begin dynamic</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/position choice</name>
        <message>
            <source>let's forme your name's first letter, so tell me, what is your name ?</source>
            <comment>Text</comment>
            <translation type="obsolete">let's forme your name's first letter, so tell me, what is your name ?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>follow my lead</source>
            <comment>Text</comment>
            <translation type="unfinished">follow my lead</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/showing position</name>
        <message>
            <source>it's showtime !</source>
            <comment>Text</comment>
            <translation type="obsolete">it's showtime !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/try again</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Try again</source>
            <comment>Text</comment>
            <translation type="unfinished">Try again</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/try again (1)</name>
        <message>
            <source>Keep your arm closer to your body</source>
            <comment>Text</comment>
            <translation type="obsolete">Keep your arm closer to your body</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/you win</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>congratulation, that was flawless</source>
            <comment>Text</comment>
            <translation type="unfinished">congratulation, that was flawless</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Dynamic Game/your turn !</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>it's showtime !</source>
            <comment>Text</comment>
            <translation type="unfinished">it's showtime !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Endgame/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Do you want to do another turn ?</source>
            <comment>Text</comment>
            <translation type="unfinished">Do you want to do another turn ?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Endgame/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Too bad, see you later !</source>
            <comment>Text</comment>
            <translation type="unfinished">Too bad, see you later !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Gamemode/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>raise one finger if you want to do static position, or two finger for movements.</source>
            <comment>Text</comment>
            <translation type="unfinished">raise one finger if you want to do static position, or two finger for movements.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Gamemode/Say mode 1</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Of cours, you chosed to play in easy mode</source>
            <comment>Text</comment>
            <translation type="unfinished">Of cours, you chosed to play in easy mode</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Gamemode/Say mode 2</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>ready to move you body !</source>
            <comment>Text</comment>
            <translation type="unfinished">ready to move you body !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Gamemode/Say mode Other</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Please, don't you know how to count to two ?</source>
            <comment>Text</comment>
            <translation type="unfinished">Please, don't you know how to count to two ?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Greetings/Hello !</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello !</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Greetings/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>now that we're both aware of each other, let's play a game !</source>
            <comment>Text</comment>
            <translation type="unfinished">now that we're both aware of each other, let's play a game !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Rules/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>do you want me to explain the rules ?</source>
            <comment>Text</comment>
            <translation type="unfinished">do you want me to explain the rules ?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Rules/Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I will sow you position that you will need to remember and reproduce when i tell tou to.</source>
            <comment>Text</comment>
            <translation type="unfinished">I will sow you position that you will need to remember and reproduce when i tell tou to.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Setting up connection</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Setting up connection</source>
            <comment>Text</comment>
            <translation type="unfinished">Setting up connection</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/detected</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Great ! Hold it now</source>
            <comment>Text</comment>
            <translation type="unfinished">Great ! Hold it now</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/intro static</name>
        <message>
            <source>begin static</source>
            <comment>Text</comment>
            <translation type="obsolete">begin static</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/position choice</name>
        <message>
            <source>let's forme your name's first letter, so tell me, what is your name ?</source>
            <comment>Text</comment>
            <translation type="obsolete">let's forme your name's first letter, so tell me, what is your name ?</translation>
        </message>
        <message>
            <source>let's forme your name's first letter, so tell me, what is it ?</source>
            <comment>Text</comment>
            <translation type="obsolete">let's forme your name's first letter, so tell me, what is it ?</translation>
        </message>
        <message>
            <source>Let's forme your name's first letter, so tell me, what is it</source>
            <comment>Text</comment>
            <translation type="obsolete">Let's forme your name's first letter, so tell me, what is it</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Let's forme your name's first lette</source>
            <comment>Text</comment>
            <translation type="unfinished">Let's forme your name's first lette</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/position choice (1)</name>
        <message>
            <source>it's showtime !</source>
            <comment>Text</comment>
            <translation type="obsolete">it's showtime !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/showing position</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>it's showtime !</source>
            <comment>Text</comment>
            <translation type="unfinished">it's showtime !</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/try again</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Try again</source>
            <comment>Text</comment>
            <translation type="unfinished">Try again</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/you win</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>congratulation, that was flawless</source>
            <comment>Text</comment>
            <translation type="unfinished">congratulation, that was flawless</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Static Game/your turn !</name>
        <message>
            <source>it's showtime !</source>
            <comment>Text</comment>
            <translation type="obsolete">it's showtime !</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Your turn</source>
            <comment>Text</comment>
            <translation type="unfinished">Your turn</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/connection established</name>
        <message>
            <source>connection establishes, I'not stealing your credit card information</source>
            <comment>Text</comment>
            <translation type="obsolete">connection establishes, I'not stealing your credit card information</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>connection established, I'not stealing your credit card information</source>
            <comment>Text</comment>
            <translation type="unfinished">connection established, I'not stealing your credit card information</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/detected</name>
        <message>
            <source>Great ! Hold it now</source>
            <comment>Text</comment>
            <translation type="obsolete">Great ! Hold it now</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/position choice</name>
        <message>
            <source>Let's forme your name's first lette</source>
            <comment>Text</comment>
            <translation type="obsolete">Let's forme your name's first lette</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/showing position</name>
        <message>
            <source>let me show you the way</source>
            <comment>Text</comment>
            <translation type="obsolete">let me show you the way</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/try again</name>
        <message>
            <source>Try again</source>
            <comment>Text</comment>
            <translation type="obsolete">Try again</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/you win</name>
        <message>
            <source>congratulation, that was flawless</source>
            <comment>Text</comment>
            <translation type="obsolete">congratulation, that was flawless</translation>
        </message>
    </context>
</TS>
